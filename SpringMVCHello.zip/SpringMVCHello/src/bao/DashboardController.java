package bao;


import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import dao.Register;
import dao.Review;
@Controller
public class DashboardController {
	@RequestMapping("userdash")
	public ModelAndView home()
	{
		return new ModelAndView("userdash");
	}
	@RequestMapping("addreview")
	public ModelAndView addreview()
	{
		return new ModelAndView("addreview","command",new Review());
	}
	@RequestMapping("reviewlogic")
	public ModelAndView reviewLogic(HttpServletRequest request,@ModelAttribute("SpringMVCHello")Review r, ModelMap model)
	{
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf = cfg.buildSessionFactory();
		Session s = sf.openSession();
		Transaction tx = s.beginTransaction();
		HttpSession sess = request.getSession();
		r.setReviewby(sess.getAttribute("uid").toString());
		s.save(r);
		tx.commit();
		s.close();
		String st = "Reg successfully";
		ModelAndView obj =new ModelAndView("addreview", "command", new Review());
		obj.addObject("res",  "Result is "+st);
		return obj;
	}
	@RequestMapping("viewreview")
	public ModelAndView viewreview(HttpServletRequest request, HttpServletResponse response)
	{
		HttpSession  sess = request.getSession();
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf = cfg.buildSessionFactory();
		Session s = sf.openSession();
		Query q = s.createQuery("from Review s where s.reviewby=?");
		q.setString(0, sess.getAttribute("uid").toString());
		List lst = q.list();
		s.close();
		return new ModelAndView("viewreview","res",lst);
	}

}
