package bao;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import dao.PrimeNum;;

@Controller
public class PrimeController {
	
	@RequestMapping("prime")
	public ModelAndView pload()
	{
		return new ModelAndView("prime", "command", new PrimeNum());
	}
	
	@RequestMapping("primelogic")
	public ModelAndView primeLogic(@ModelAttribute("SpringMVCHello")PrimeNum s, ModelMap model)
	{
		String result="";
		int i;
		for(i=2;i<s.getNum();i++)
		{
			if(s.getNum()%i==0)
			{
				result = "Not prime";
				break;
			}
		}
		if(s.getNum()==i)
		{
			result = "prime"; 
		}
		ModelAndView obj =new ModelAndView("prime", "command", new PrimeNum());
		obj.addObject("res",  "Result is "+result);
		 return obj ;
	}

}
