package bao;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import dao.SI;
@Controller
public class SIController {
	@RequestMapping("siload")
	public ModelAndView siLoad()
	{
		 return new ModelAndView("siform", "command", new SI());
	}
	@RequestMapping("silogic")
	public ModelAndView siLogic(@ModelAttribute("SpringMVCHello")SI s, ModelMap model)
	{
		float si = (s.getP()*s.getR()*s.getT())/100;
		ModelAndView obj =new ModelAndView("siform", "command", new SI());
		obj.addObject("res",  "Result is "+si);
		 return obj ;
	}

}
