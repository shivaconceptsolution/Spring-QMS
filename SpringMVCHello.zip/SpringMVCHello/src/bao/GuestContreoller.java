package bao;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class GuestContreoller {
@RequestMapping("home")	
public String home()
{
	return "home";
}
@RequestMapping("about")	
public String about()
{
	return "about";
}
@RequestMapping("service")	
public String services()
{
	return "service";
}
@RequestMapping("gallery")	
public String gallery()
{
	return "gallery";
}
@RequestMapping("contact")	
public String contact()
{
	return "contact";
}
}
