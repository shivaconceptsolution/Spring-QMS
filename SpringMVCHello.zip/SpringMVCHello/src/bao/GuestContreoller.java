package bao;


import org.hibernate.cfg.*;
import org.hibernate.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import dao.Register;
import dao.SI;
@Controller
public class GuestContreoller {
@RequestMapping("home")	
public ModelAndView home()
{
	return new ModelAndView("home","command", new Register());
}

@RequestMapping("reglogic")
public ModelAndView siLogic(@ModelAttribute("SpringMVCHello")Register r, ModelMap model)
{
	Configuration cfg = new Configuration();
	cfg.configure("hibernate.cfg.xml");
	SessionFactory sf = cfg.buildSessionFactory();
	Session s = sf.openSession();
	Transaction tx = s.beginTransaction();
	s.save(r);
	tx.commit();
	s.close();
	String st = "Reg successfully";
	ModelAndView obj =new ModelAndView("home", "command", new Register());
	obj.addObject("res",  "Result is "+st);
	return obj;
}
@RequestMapping("about")	
public String about()
{
	return "about";
}
@RequestMapping("service")	
public String services()
{
	return "service";
}
@RequestMapping("gallery")	
public String gallery()
{
	return "gallery";
}
@RequestMapping("contact")	
public String contact()
{
	return "contact";
}
}
