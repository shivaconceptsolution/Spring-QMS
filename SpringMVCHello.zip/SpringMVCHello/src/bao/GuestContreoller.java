package bao;
import java.util.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.hibernate.cfg.*;
import org.hibernate.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import dao.Register;
import dao.SI;
@Controller
public class GuestContreoller {
@RequestMapping("home")	
public ModelAndView home()
{
	return new ModelAndView("home","command", new Register());
}

@RequestMapping("reglogic")
public ModelAndView siLogic(@ModelAttribute("SpringMVCHello")Register r, ModelMap model)
{
	Configuration cfg = new Configuration();
	cfg.configure("hibernate.cfg.xml");
	SessionFactory sf = cfg.buildSessionFactory();
	Session s = sf.openSession();
	Transaction tx = s.beginTransaction();
	s.save(r);
	tx.commit();
	s.close();
	String st = "Reg successfully";
	ModelAndView obj =new ModelAndView("home", "command", new Register());
	obj.addObject("res",  "Result is "+st);
	return obj;
}
@RequestMapping("login")	
public ModelAndView login()
{
	return new ModelAndView("login","command", new Register());
}
@RequestMapping("loginlogic")
public ModelAndView loginLogic(HttpServletRequest request,@ModelAttribute("SpringMVCHello")Register r, ModelMap model)
{
	String st;
	Configuration cfg = new Configuration();
	cfg.configure("hibernate.cfg.xml");
	SessionFactory sf = cfg.buildSessionFactory();
	Session s = sf.openSession();
	Query q = s.createQuery("from Register r where r.username=? and r.password=?");
	q.setString(0,r.getUsername());
	q.setString(1,r.getPassword());
	List lst = q.list();
	if(lst.size()>0)
	{
		HttpSession  sess = request.getSession();
		sess.setAttribute("uid",r.getUsername());
		return new ModelAndView("redirect:userdash.html");
	}
	else
	{
		st = "Invalid userid and password";
	}
	s.close();
	
	ModelAndView obj =new ModelAndView("login", "command", new Register());
	obj.addObject("res",  "Result is "+st);
	return obj;
}
@RequestMapping("about")	
public String about()
{
	return "about";
}
@RequestMapping("service")	
public String services()
{
	return "service";
}
@RequestMapping("gallery")	
public String gallery()
{
	return "gallery";
}
@RequestMapping("contact")	
public String contact()
{
	return "contact";
}
}
