package dao;

import javax.persistence.*;

@Entity
@Table(name="review")
public class Review {
@Id	
private int reviewid;
@Column
private String reviewby;
@Column
private String reviewto;
public int getReviewid() {
	return reviewid;
}
public void setReviewid(int reviewid) {
	this.reviewid = reviewid;
}
public String getReviewby() {
	return reviewby;
}
public void setReviewby(String reviewby) {
	this.reviewby = reviewby;
}
public String getReviewto() {
	return reviewto;
}
public void setReviewto(String reviewto) {
	this.reviewto = reviewto;
}
public String getReviewdesc() {
	return reviewdesc;
}
public void setReviewdesc(String reviewdesc) {
	this.reviewdesc = reviewdesc;
}
public float getReviewrate() {
	return reviewrate;
}
public void setReviewrate(float reviewrate) {
	this.reviewrate = reviewrate;
}
public String getReviewdept() {
	return reviewdept;
}
public void setReviewdept(String reviewdept) {
	this.reviewdept = reviewdept;
}
@Column
private String reviewdesc;
@Column
private float reviewrate;
@Column
private String reviewdept;

}
